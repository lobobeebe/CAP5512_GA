import java.util.Random;

public class StrategyAxelrodTitForTat extends StrategyAxelrod
{
    public StrategyAxelrodTitForTat(Random randomizer, ConfigManager configManager)
    {
        super(randomizer, configManager);
        name = "Axelrod Tit For Tat Mix";
    }

    @Override
    protected int getMoveFromStrategyValue(int strategyValue)
    {
        int move;

        if (strategyValue < 0)
        {
            move = getOpponentLastMove();
        }
        else
        {
            move = strategyValue;
        }

        return move;
    }
}
